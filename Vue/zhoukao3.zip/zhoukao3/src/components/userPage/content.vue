<template>
  <div class="content">
        我是内容
  </div>
</template>

<script>
export default {
    name: 'content'
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.content{
  padding:10px 50px;
}
</style>
